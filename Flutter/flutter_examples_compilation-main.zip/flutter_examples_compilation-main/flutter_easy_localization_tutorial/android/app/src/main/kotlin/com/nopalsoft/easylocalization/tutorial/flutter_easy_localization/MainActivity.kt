package com.nopalsoft.easylocalization.tutorial.flutter_easy_localization

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
