import 'package:flutter_flavors_ios_android/environment/environment.dart';
import 'package:flutter_flavors_ios_android/main.dart';

void main() => mainApp(Environment.prod);





















