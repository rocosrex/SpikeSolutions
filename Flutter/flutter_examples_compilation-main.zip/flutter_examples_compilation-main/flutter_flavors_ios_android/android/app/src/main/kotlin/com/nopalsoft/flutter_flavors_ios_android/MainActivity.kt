package com.nopalsoft.flutter_flavors_ios_android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
