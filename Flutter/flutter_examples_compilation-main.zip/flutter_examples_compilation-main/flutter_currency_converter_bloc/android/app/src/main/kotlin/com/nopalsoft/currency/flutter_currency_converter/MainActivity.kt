package com.nopalsoft.currency.flutter_currency_converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
