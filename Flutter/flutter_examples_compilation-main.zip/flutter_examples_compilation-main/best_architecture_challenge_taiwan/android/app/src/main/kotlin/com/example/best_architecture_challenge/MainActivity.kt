package com.example.best_architecture_challenge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
