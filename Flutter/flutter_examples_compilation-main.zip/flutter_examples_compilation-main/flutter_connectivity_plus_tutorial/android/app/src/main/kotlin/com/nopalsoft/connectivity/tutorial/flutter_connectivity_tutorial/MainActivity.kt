package com.nopalsoft.connectivity.tutorial.flutter_connectivity_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
