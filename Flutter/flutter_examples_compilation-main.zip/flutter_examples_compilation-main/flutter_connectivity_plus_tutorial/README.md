# Flutter Connectivity 

Created on Flutter Stable 2.0.3
Working on Flutter Stable 2.10.5

How to check if the device has an internet connection

# Screenshots

| Internet | No Internet |
| ---------------- | --------------------- |
| ![Image 1](screenshots/image1.png) |![Image 2](screenshots/image2.png) |

# Youtube Video
[![Youtube](screenshots/youtube.png)](https://youtu.be/gNNpaXeu9XU)