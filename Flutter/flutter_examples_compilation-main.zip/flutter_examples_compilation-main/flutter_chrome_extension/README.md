# Create a Chrome Extension with Flutter

Do you want to learn how to create a Chrome Extension with Flutter: Read the article:

- [Tutorial in spanish](https://www.yayocode.com/2021/07/crear-una-extension-para-google-chrome.html)
- [Tutorial in english](https://www.yayocode.com/2021/07/how-to-create-google-chrome-extension.html)

Or watch the videotutorial in youtube (in spanish)
# Video
[![Youtube](screenshots/youtube.png)](https://youtu.be/7U5423IARvU)


