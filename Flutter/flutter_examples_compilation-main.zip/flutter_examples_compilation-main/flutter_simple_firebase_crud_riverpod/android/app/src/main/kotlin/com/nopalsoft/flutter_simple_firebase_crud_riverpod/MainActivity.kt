package com.nopalsoft.flutter_simple_firebase_crud_riverpod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
