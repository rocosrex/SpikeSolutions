package com.nopalsoft.flutter_simple_firebase_crud_cubit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
