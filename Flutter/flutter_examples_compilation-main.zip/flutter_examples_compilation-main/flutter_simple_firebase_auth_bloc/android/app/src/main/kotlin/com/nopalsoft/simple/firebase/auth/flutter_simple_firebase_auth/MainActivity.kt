package com.nopalsoft.simple.firebase.auth.flutter_simple_firebase_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
