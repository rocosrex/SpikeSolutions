package com.nopalsoft.flutter_bloc_architecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
